<?php

include "../config/config.php";
include "../system/init.php";

?>