<?php

// Database configurations 

define("HOST", "localhost");
define("USER", "root");
define("DATABASE", "company");
define("PASSWORD", "");

// Base URL

define("BASEURL", "http://localhost/MVCFramework");
define("ROOT", "http://localhost/MVCFramework/public");

?>