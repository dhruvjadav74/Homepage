<?php



class userModel extends database {

    public function userSignup($name,$email,$phonenumber,$message){


        if($this->Query("Insert INTO contactus(Name, Email, PhoneNumber,Message) 
        VALUES (?,?,?,?)", [ $name,$email,$phonenumber,$message])){
            return true;
        }
        else{
            return false;
        }
    }
}


?>