
<?php

class accountController extends framework{

    public function  __construct(){
        $this->helper("link");
    }

    public function  index(){
        $this->view("homepage");
    }

    public function  pricesPage(){
        $this->view("prices");
    }

    
    public function  contactPage(){
        $this->view("userView");
    }

    public function contactUs(){
        $this->view('contactus');
    }

    public function aboutPage(){
        $this->view('about');
    }
    public function faqPage(){
        $this->view('faq');
    }

    public function signup(){
        $userModel= $this->model('userModel');
         $name= $this->input('name');
         $email= $this->input('email');
         $message= $this->input('message');
         $phonenumber= $this->input('phonenumber');
                    if($userModel->userSignup($name,$email,$phonenumber,$message)){
                      
                  } 
        
            } 


}
?>
