<nav class="navbar navbar-expand-lg navbar-light bg-transparent Rectangle sticky-top">
            <div class="container-fluid">
              <a class="navbar-brand" href="#"><img class="img" src="<?=ROOT?>/assets/Images/homepage/white-logo-transparent-background.png" alt=""></a>
              <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
              </button>
              <div class="collapse navbar-collapse" id="navbarSupportedContent" >
                <ul class="navbar-nav ms-auto mb-2 mb-lg-0" >
                  <li class="nav-item">
                    <a class="nav-link border text-center" aria-current="page" href="#" style=" width: 161px;">Book a cleaner</a>
                  </li>
                  <li class="nav-item">
                    <a class="nav-link" href="<?php echo BASEURL; ?>/accountController/pricesPage">Prices</a>
                  </li>
                  
                  <li class="nav-item">
                    <a class="nav-link" href="<?php echo BASEURL; ?>/accountController">Our Guarantee</a>
                  </li>
                  <li class="nav-item">
                    <a class="nav-link" href="<?php echo BASEURL; ?>/accountController/contactPage">Blog</a>
                  </li>
                  <li class="nav-item">
                    <a class="nav-link" href="<?php echo BASEURL; ?>/accountController/contactUs">Contact</a>
                  </li>
                  <li class="nav-item">
                    <a class="nav-link border br1 text-center" href="#" >Login</a>
                  </li>
                  <li class="nav-item">
                    <a class="nav-link border br2 text-center" href="#">Become a Helper</a>
                  </li>
                  <li class="nav-item dropdown">
                    <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                      <img src=" <?=ROOT?>/assets/images/homepage/flag.png" alt="">
                    </a>
                    <ul class="dropdown-menu" aria-labelledby="navbarDropdown">
                    </ul>
                  </li>
                </ul>
               
                
    
                
              </div>
            </div>
          </nav>