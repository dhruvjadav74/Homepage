<Header>
        <div class="container-fluid header1">
            <!-- navbar -->
            <nav class="navbar  navbar-expand-lg  navbar-dark">
                <div class="container-fluid">
                    <img src=" <?=ROOT?>/assets/Images/contact/logo-small.png">

                    <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#collapsenavbar">
                <span class="navbar-toggler-icon"></span>
            </button>
                    <div class="collapse navbar-collapse menu1" id="collapsenavbar">
                        <ul class="navbar-nav ml-auto text-center">
                            <li class="nav-item">
                                <Button value="" style="background-color: rgba(0, 96, 114, 0.5);border-radius: 20px;border: 1px solid rgba(255, 255, 255, 0.5);height: 40px;width: 100px; color: aliceblue;">Book now</Button>
                            </li>
                            <li class="nav-item">
                                <Button value="" style="background-color: rgb(82, 82, 82);border-radius: 20px;border: 1px solid rgba(255, 255, 255, 0.5);height: 40px;width: 161px; color: aliceblue;">Prices & services</Button>
                            </li>
                            <li class="nav-item">
                                <a href="" class="nav-link text-white"><span>Warranty</span></a>
                            </li>
                            <li class="nav-item">
                                <a href="#blog" class="nav-link text-white"><span>Blog</span></a>
                            </li>
                            <li class="nav-item">
                                <a href="<?php echo BASEURL; ?>/accountController/contactUs" class="nav-link text-white"><span>Contact</span></a>
                            </li>
                            <li class="nav-item">
                                <Button value="" style="background-color: rgba(0, 96, 114, 0.5);border-radius: 20px;border: 1px solid rgba(255, 255, 255, 0.5);height: 40px;width: 70px; color: aliceblue;">Login</Button>
                            </li>
                            <li class="nav-item">
                                <Button value="" style="background-color: rgba(0, 96, 114, 0.5);border-radius: 20px;border: 1px solid rgba(255, 255, 255, 0.5);height: 40px;width: 140px; color: aliceblue;">Become a helper</Button>
                            </li>
                        </ul>
                    </div>
                </div>
            </nav>
        </div>
    </Header>