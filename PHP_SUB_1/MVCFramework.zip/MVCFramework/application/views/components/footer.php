<footer>
    <div class="row footer justify-content-between">
      
      <div class="col-12 col-md-1 text-center " style="padding-top: 20px;padding-left: 100px;" >
        <img src="<?=ROOT?>/assets/Images/homepage/logo-small.png">
      </div>
      <div class="col-md-auto my-auto">
        <ul >
          <li><a href="#" style="text-decoration: none;">HOME</a></li>
          <li><a href="<?php echo BASEURL; ?>/accountController/aboutPage" style="text-decoration: none;">ABOUT</a></li>
          <li><a href="#" style="text-decoration: none;">TESTIMONIALS</a></li>
          <li><a href="<?php echo BASEURL; ?>/accountController/faqPage"  style="text-decoration: none;">FAQS</a></li>
          <li><a href="#" style="text-decoration: none;">INSURANCE</a></li>
          <li><a href="#" style="text-decoration: none;">POLICY</a></li>
          <li><a href="#" style="text-decoration: none;">IMPRESSUM</a></li>
        </ul>
      </div>
      <div class="col-12 col-md-1 my-auto">
        <div  class="social-media justify-content-center">
          <a class="nav-link"><img src="<?=ROOT?>/assets/images/homepage/facbook.png"></a>
          <a class="nav-link"><img src="<?=ROOT?>/assets/images/homepage/instagram.png"></a>
        </div>
      </div>
      
      <hr class="mx-auto "style="border:1px solid #424242;width:1320px;">
      <div class="row mx-auto">
        <div class="col text-center">
          <p style="color:#9BA0A3">©2018 Helperland. All rights reserved.   Terms and Conditions | Privacy Policy</p>
        </div>
        
      </div>
      
      
    </div>
  </footer>