<section>
        <div class="container">
          <h2 class="text-center" style="margin-top: 1rem;">GET OUR NEWSLETTER</h2>
        </div>
      </section>

      <div class="row d-flex justify-content-center" style="margin-bottom: 2%;">
            <div class="col-md-2 ">
                
             <input type="text" class="form-control" placeholder="Your email" style=" width: 233px;border-radius: 20px;border: solid 1px #565656;background-color: #f4f5f8;">
            </div>
                <div class="col-md-1 d-flex justify-content-center">
              <button class="btn btn-primary" style="width: 163px; border-radius: 20px;background-color: #ff7b6d;" type="submit">Submit</button>
            </div>
         </div>    

      </section>