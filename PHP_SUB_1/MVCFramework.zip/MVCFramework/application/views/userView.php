<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
    <title>Document</title>
</head>
<body>

  <form action="http://localhost/MVCFramework/userController/signup" method="POST" >
  			<div class="row d-flex justify-content-center">
	    			<div class="col-md-3 ">
	     			 <input type="text" class="form-control" name="fullName" placeholder="First name">
    				</div>
    		        <div class="col-md-3">
     				 <input type="text" class="form-control" placeholder="Last name">
  	  			</div>
  		   </div>
  		   <div class="row d-flex justify-content-center" style="margin-top: 1rem;">
	    			<div class="col-md-3">
                      <label class="sr-only" for="inlineFormInputGroup">Mobile number</label>
                       <div class="input-group mb-2">
                         <div class="input-group-prepend">
                           <div class="input-group-text">+49</div>
                     </div>
                      <input type="number" class="form-control" name="phonenumber" placeholder="Mobile number">
                </div>
           </div>
    		        <div class="col-md-3">
     				  <input type="email" class="form-control" name="email" id="inputEmail4" placeholder="Email">
               
  	  			</div>
  		   </div>
  		   <div class="row d-flex justify-content-center" style="margin-top: 1rem;">
  		   	<div class="col-md-6">
  		    <div class="form-group">
              <select class="form-control" id="exampleFormControlSelect1">
               <option>Subject</option>
              </select>
            </div>
           </div>
      </div>
	
    <div class="row d-flex justify-content-center" style="margin-top: 1rem;">
			<div class="col-md-6">
			 <div class="form-group">
               <textarea class="form-control" id="exampleFormControlTextarea1" rows="5" name="message" placeholder="Message"></textarea>
            </div>
        </div>
		</div>
	</div>
		<div class="d-flex justify-content-center">
			<button class="btn btn-primary" style="width: 163px; border-radius: 23px;background-color: #1d7a8c;" type="submit">Submit</button>
		</div>
    </form>
</body>
</html>